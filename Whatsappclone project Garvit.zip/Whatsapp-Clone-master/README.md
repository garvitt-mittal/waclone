# Whatsapp-Clone
Whatsapp clone android app coded in Java. The app uses firebase for authentication of user as well as storage of data. 

## Screenshots
<img src="https://github.com/gtiwari912/Whatsapp-Clone/blob/master/Screenshots/ss2.png" width="275" height="460"> 
<img src="https://github.com/gtiwari912/Whatsapp-Clone/blob/master/Screenshots/ss4.png" width="275" height="460">
<img src="https://github.com/gtiwari912/Whatsapp-Clone/blob/master/Screenshots/ss1.png" width="275" height="460">
<!-- <img src="https://github.com/gtiwari912/Whatsapp-Clone/blob/master/Screenshots/ss3.png" width="275" height="460"> -->

## Installation

Download the project either by git clone or download and extract the zip, then load the project in your android studio. You are free to do the modifications as your wish
You can even directly try app by installing in your phone, the apk file is in "releases" folder, or you can get it by <a href="https://github.com/gtiwari912/Whatsapp-Clone/blob/master/app/release/app-release.apk">clicking here.</a> 
